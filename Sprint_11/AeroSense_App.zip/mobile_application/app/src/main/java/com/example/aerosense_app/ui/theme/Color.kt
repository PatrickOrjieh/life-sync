package com.example.aerosense_app.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFFFFFFF)
val PurpleGrey80 = Color(0xFFFFFFFF)
val Pink80 = Color(0xFFFFFFFF)

val Purple40 = Color(0xFF2596be)
val PurpleGrey40 = Color(0xFFFFFFFF)
val Pink40 = Color(0xFFFFFFFF)