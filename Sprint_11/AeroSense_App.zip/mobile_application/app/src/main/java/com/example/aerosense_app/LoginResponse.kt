package com.example.aerosense_app

data class LoginResponse(
    val success: Boolean,
    val message: String
)