package com.example.aerosense_app

data class SettingsResponse(
    val success: Boolean,
    val message: String,
)

