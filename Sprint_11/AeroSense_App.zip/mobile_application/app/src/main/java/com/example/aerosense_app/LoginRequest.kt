package com.example.aerosense_app

data class LoginRequest(
    val email: String,
    val password: String
)