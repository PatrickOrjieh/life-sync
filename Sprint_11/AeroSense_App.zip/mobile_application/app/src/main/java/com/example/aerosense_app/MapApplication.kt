package com.example.aerosense_app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
//Parts of code taken from: https://github.com/mitchtabian/Google-Maps-Compose
@HiltAndroidApp
class MapApplication: Application()