package com.example.aerosense_app
data class RegisterResponse(
    val message: String,
    val firebaseUID: String,
    val userID: Int
)